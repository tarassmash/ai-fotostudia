# СВЕТ — AI-фотостудия

Клиент загружает селфи, выбирает образ и через 30–60 секунд получает студийные портреты с сохранением лица. Генерация идёт через fal.ai (по умолчанию модель Nano Banana Pro). Ключ fal.ai хранится на сервере Netlify и не попадает в браузер клиента.

## Как опубликовать на Netlify (без командной строки)

1. **Загрузите проект на GitHub.** Зайдите на github.com → New repository → назовите, например, `ai-photostudio` → Create. На странице репозитория нажмите «uploading an existing file» и перетащите **содержимое** этой папки (файлы `netlify.toml`, `package.json`, `README.md` и папки `public`, `netlify`). Нажмите Commit changes.
2. **Подключите к Netlify.** app.netlify.com → Add new site → Import an existing project → GitHub → выберите репозиторий. Настройки сборки менять не нужно, они в `netlify.toml`. Нажмите Deploy.
3. **Добавьте ключ.** Site configuration → Environment variables → Add a variable:
   - `FAL_KEY` = ваш ключ fal.ai
4. **Перезапустите деплой:** Deploys → Trigger deploy → Deploy site. Готово, сайт работает по адресу вида `имя.netlify.app`.

Простое перетаскивание папки в Netlify Drop не подойдёт: так Netlify не запускает серверные функции, а без них ключ пришлось бы показывать в браузере.

## Настройки (переменные окружения в Netlify)

| Переменная | Что делает | По умолчанию |
|---|---|---|
| `FAL_KEY` | Ключ fal.ai (обязательно) | — |
| `STUDIO_ACCESS_CODE` | Код доступа. Если задан, генерировать могут только клиенты, которым вы дали код. **Рекомендуется**: иначе любой посетитель тратит ваш баланс fal.ai | не задан |
| `FAL_MODEL` | Модель fal.ai | `fal-ai/nano-banana-pro/edit` |
| `FAL_RESOLUTION` | Разрешение: `1K`, `2K` или `4K` | `2K` |
| `MAX_VARIANTS` | Максимум вариантов за раз (1–4) | `4` |

После изменения переменных сделайте Trigger deploy.

Альтернативные модели для `FAL_MODEL`: `fal-ai/nano-banana/edit` (быстрее и дешевле), `fal-ai/bytedance/seedream/v4/edit`.

## Как изменить стили, промпты, название

- Образы и промпты: `netlify/shared/studio.mjs`, массив `STYLES`. Можно добавить свой стиль, скопировав блок. Общие правила сохранения лица заданы в `IDENTITY`, качество съёмки в `QUALITY`.
- Название «СВЕТ», тексты и цвета: `public/index.html`.

## Расходы

Каждый вариант оплачивается в fal.ai отдельно. Nano Banana Pro заметно дороже обычной Nano Banana, а 4K дороже 2K. Актуальные цены смотрите на странице модели на fal.ai. Поставьте лимит расходов в личном кабинете fal.ai и включите `STUDIO_ACCESS_CODE`, если сайт открыт всем.

## Структура

```
public/index.html            сайт для клиента
netlify/functions/config.mjs     список стилей и настроек
netlify/functions/generate.mjs   принимает фото и ставит задачу в fal.ai
netlify/functions/status.mjs     проверяет готовность и отдаёт снимки
netlify/shared/studio.mjs        модель, стили, промпты
netlify.toml                     настройки Netlify
```

Локальный запуск для разработчика: `npx netlify-cli dev` (ключ положить в файл `.env` как `FAL_KEY=...`).
