// Общие настройки студии: модель, стили и промпты.
// Промпты живут только на сервере — клиент видит лишь названия стилей.

export const MODEL = process.env.FAL_MODEL || "fal-ai/nano-banana-pro/edit";
export const RESOLUTION = process.env.FAL_RESOLUTION || "2K"; // 1K | 2K | 4K (для Nano Banana Pro)
export const MAX_IMAGES = Math.min(4, Math.max(1, parseInt(process.env.MAX_VARIANTS || "4", 10)));
export const ACCESS_CODE = (process.env.STUDIO_ACCESS_CODE || "").trim();

const IDENTITY = [
  "Use the person from the reference photo(s) as the only subject.",
  "Preserve their exact facial identity with maximum fidelity: identical face shape, jawline, eyes (shape, color, spacing), eyebrows, nose, lips, ears, skin tone, freckles, moles, scars, age, hairline, hair color and texture, facial hair.",
  "The result must be instantly recognizable as the same real person by friends and family.",
  "Do not change ethnicity, age, body type or facial proportions. Do not beautify into a different face, do not slim the face, do not enlarge the eyes.",
  "If the reference shows glasses, keep the same glasses.",
].join(" ");

const QUALITY = [
  "Photorealistic high-end commercial portrait photography, shot on a Phase One medium format camera with an 85mm lens.",
  "Tack-sharp focus on the eyes, natural catchlights, realistic skin texture with visible pores, subtle professional retouching (dodge and burn), no plastic or waxy skin, no oversmoothing.",
  "Accurate anatomy, natural hands if visible, correct teeth, no extra fingers, no distortion, no text, no watermark, no logo.",
  "Magazine-grade color grading, rich tonal range, clean highlights, deep but detailed shadows.",
].join(" ");

// light — подпись о схеме света (показывается клиенту как деталь стиля)
// swatch — CSS-градиент, имитирующий свет на фоне (для карточки стиля)
export const STYLES = [
  {
    id: "business",
    name: "Деловой портрет",
    desc: "Для сайта компании, резюме и LinkedIn. Строгий костюм, серый фон.",
    light: "85 мм · f/4 · октабокс 150 + контровой",
    swatch: "radial-gradient(circle at 35% 30%, #d8dbe0 0%, #9aa1ab 45%, #4a5059 100%)",
    prompt: "Premium corporate headshot, chest-up framing, subject slightly turned, confident approachable expression with a subtle natural smile. Wardrobe: impeccably tailored dark navy or charcoal suit or blazer with a crisp shirt, styled appropriately for the person. Background: neutral mid-grey seamless studio paper with a soft gradient. Lighting: large octabox key light at 45 degrees, soft fill, gentle hair light separating the subject from the background.",
  },
  {
    id: "office",
    name: "Современный офис",
    desc: "Дружелюбный портрет в светлом офисе с мягким размытием.",
    light: "85 мм · f/1.8 · окно + отражатель",
    swatch: "linear-gradient(135deg, #f4f1ea 0%, #c9d6de 45%, #7f98a8 100%)",
    prompt: "Modern professional portrait in a bright contemporary office with large windows, background beautifully blurred with creamy bokeh (glass, plants, warm wood). Waist-up framing, relaxed confident posture, genuine warm smile. Wardrobe: smart-casual, a quality blazer or knit over a clean shirt. Lighting: soft natural window light as key, white bounce fill, airy and optimistic mood.",
  },
  {
    id: "bw_classic",
    name: "Классика Ч/Б",
    desc: "Благородный чёрно-белый портрет в духе студийной классики.",
    light: "105 мм · f/5.6 · рембрандтовский свет",
    swatch: "radial-gradient(circle at 30% 35%, #bdbdbd 0%, #505050 40%, #0e0e0e 80%)",
    prompt: "Timeless black and white fine-art studio portrait, head and shoulders, deep black background. Rembrandt lighting with a single key light creating a small triangle of light on the shadow cheek, dramatic yet refined contrast, silver gelatin film look with fine grain, thoughtful calm expression. Wardrobe: simple dark clothing, no patterns.",
  },
  {
    id: "editorial",
    name: "Обложка журнала",
    desc: "Модная съёмка: сочный цветной фон, свет как на обложке.",
    light: "70 мм · f/8 · бьюти-тарелка",
    swatch: "radial-gradient(circle at 50% 30%, #ffb38a 0%, #e0583a 45%, #7a1f1a 100%)",
    prompt: "High-fashion magazine editorial portrait, bold saturated solid color seamless backdrop that complements the subject's skin tone, beauty dish key light from above-front with a clean catchlight, crisp specular highlights. Stylish contemporary designer outfit, strong confident pose, editorial styling of hair. Vogue / GQ cover quality, leave clean negative space above the head.",
  },
  {
    id: "golden_hour",
    name: "Золотой час",
    desc: "Тёплый закатный свет на улице, живое естественное настроение.",
    light: "135 мм · f/2 · контровое солнце",
    swatch: "radial-gradient(circle at 75% 25%, #fff0c2 0%, #f3b25e 35%, #8a5a3a 100%)",
    prompt: "Outdoor lifestyle portrait during golden hour, the low sun behind the subject creating a warm glowing rim light in the hair, soft golden fill on the face from a reflector, dreamy background of a park or city street dissolved into large warm bokeh. Relaxed natural expression. Wardrobe: tasteful casual clothing in warm neutral tones.",
  },
  {
    id: "luxury",
    name: "Премиум лоу-ки",
    desc: "Тёмный, дорогой, кинематографичный образ.",
    light: "85 мм · f/2.8 · стрипбокс + гобо",
    swatch: "radial-gradient(circle at 40% 40%, #3f5a5c 0%, #1b2627 50%, #07090a 100%)",
    prompt: "Luxurious low-key portrait, dark moody charcoal-teal painted canvas backdrop, narrow strip box key light sculpting the face, subtle warm accent light, cinematic color grade. Elegant premium wardrobe (dark tailored jacket, fine fabrics, understated accessories). Powerful, composed, successful look.",
  },
  {
    id: "high_key",
    name: "Светлый хай-ки",
    desc: "Чистый белый фон, мягкий свет, свежий и лёгкий снимок.",
    light: "85 мм · f/5.6 · два софтбокса + фон",
    swatch: "radial-gradient(circle at 50% 40%, #ffffff 0%, #f1f3f5 55%, #cfd5db 100%)",
    prompt: "Bright high-key studio portrait on a pure white seamless background, soft even wraparound lighting from two large softboxes plus background lights, very soft shadows, fresh and clean look, natural happy expression. Wardrobe: light neutral tones (white, cream, light grey).",
  },
  {
    id: "cinematic",
    name: "Кино-неон",
    desc: "Цветные гели, как в кадре из фильма.",
    light: "50 мм · f/1.4 · гели маджента/циан",
    swatch: "linear-gradient(120deg, #ff3fa4 0%, #6b2bd9 50%, #16c6d9 100%)",
    prompt: "Cinematic portrait with dual colored gel lighting: magenta key light from one side and cyan rim light from the other, dark background with subtle haze, anamorphic film look, moody and striking. Wardrobe: modern dark streetwear or a sleek jacket.",
  },
];

export const FORMATS = [
  { id: "4:5", name: "Портрет 4:5" },
  { id: "1:1", name: "Квадрат 1:1" },
  { id: "9:16", name: "Сторис 9:16" },
  { id: "3:2", name: "Горизонт 3:2" },
];

export function buildPrompt(style, extra) {
  const parts = [IDENTITY, style.prompt, QUALITY];
  if (extra) parts.push("Additional client wishes (follow only if they do not change the person's identity): " + extra);
  return parts.join("\n\n");
}

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

export function checkAccess(req) {
  if (!ACCESS_CODE) return true;
  return (req.headers.get("x-studio-code") || "").trim() === ACCESS_CODE;
}

export function falKey() {
  const k = process.env.FAL_KEY || process.env.FAL_API_KEY;
  if (!k) throw new Error("На сервере не задан FAL_KEY. Добавьте его в Netlify → Site configuration → Environment variables.");
  return k;
}

export async function falFetch(url, opts = {}) {
  const res = await fetch(url, {
    ...opts,
    headers: { authorization: "Key " + falKey(), "content-type": "application/json", ...(opts.headers || {}) },
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text }; }
  return { ok: res.ok, status: res.status, data };
}

export function falError(status, data) {
  let d = data?.detail ?? data?.error ?? data?.message ?? data?.raw ?? "";
  if (Array.isArray(d)) d = d.map(x => x.msg || JSON.stringify(x)).join("; ");
  else if (typeof d === "object") d = JSON.stringify(d);
  if (status === 401 || status === 403) return "Сервер не смог авторизоваться в fal.ai (проверьте FAL_KEY).";
  if (status === 402 || /balance|credit|locked/i.test(d)) return "На аккаунте fal.ai закончился баланс.";
  if (/nsfw|safety|content policy|flagged/i.test(d)) return "Фото не прошло проверку безопасности. Попробуйте другое фото.";
  return `Ошибка генерации (${status}). ${String(d).slice(0, 300)}`;
}
