import {
  MODEL, RESOLUTION, MAX_IMAGES, STYLES, FORMATS,
  buildPrompt, json, checkAccess, falFetch, falError,
} from "../shared/studio.mjs";

const DATA_URL = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Метод не поддерживается" }, 405);
  if (!checkAccess(req)) return json({ error: "Неверный код доступа." }, 401);

  let body;
  try { body = await req.json(); } catch { return json({ error: "Некорректный запрос." }, 400); }

  const photos = Array.isArray(body.photos) ? body.photos.slice(0, 3) : [];
  if (!photos.length) return json({ error: "Загрузите хотя бы одно фото." }, 400);
  if (!photos.every(p => typeof p === "string" && DATA_URL.test(p))) return json({ error: "Поддерживаются только фото JPG, PNG или WEBP." }, 400);
  const totalSize = photos.reduce((s, p) => s + p.length, 0);
  if (totalSize > 5_000_000) return json({ error: "Фото слишком большие. Попробуйте загрузить меньше снимков." }, 413);

  const style = STYLES.find(s => s.id === body.style);
  if (!style) return json({ error: "Выберите стиль портрета." }, 400);
  const format = FORMATS.find(f => f.id === body.format)?.id || "4:5";
  const count = Math.min(MAX_IMAGES, Math.max(1, parseInt(body.count, 10) || 1));
  const extra = typeof body.wishes === "string" ? body.wishes.trim().slice(0, 300) : "";

  const base = {
    prompt: buildPrompt(style, extra),
    image_urls: photos,
    num_images: count,
    output_format: "png",
  };
  const full = { ...base, aspect_ratio: format, resolution: RESOLUTION };

  const url = `https://queue.fal.run/${MODEL}`;
  let r = await falFetch(url, { method: "POST", body: JSON.stringify(full) });
  // Если модель не понимает aspect_ratio/resolution — повторяем с базовыми полями
  if (r.status === 422) r = await falFetch(url, { method: "POST", body: JSON.stringify(base) });
  if (!r.ok) return json({ error: falError(r.status, r.data) }, 502);

  const { request_id, status_url, response_url } = r.data;
  if (!request_id) return json({ error: "fal.ai не принял задачу. Попробуйте ещё раз." }, 502);
  return json({ id: request_id, statusUrl: status_url, responseUrl: response_url });
};

export const config = { path: "/api/generate" };
